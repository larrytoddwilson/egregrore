import React from 'react';
import logo from './logo.svg';
import './App.css';
import { ChatClient } from './ChatClient';

function App() {
  return (
    <div>
      <ChatClient/>
    </div>
  );
}

export default App;