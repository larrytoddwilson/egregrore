
from agents.agent import Agent

class Manager(Agent):

    def __init__(self):
        super().__init__()

    def ask(self, messages):
        # assume latest message is a url
        url = messages[-1]['content']
        spec = super().ask([self._create_spec_prompt(url)])

        competitors = super().ask([self._create_competitor_prompt(url)])
        products = self._parse_competitors(competitors)

        comparisons = ''
        for p in products:
            comparisons += super().ask([self._create_comparison_prompt(url, p)])
            break

        return f'The Specification:\n{spec}\n\nThe Competitors:\n{competitors}\n\nComparirons:\n{comparisons}'
    
    def _create_spec_prompt(self, url):
        return {'content': f'{url} is a product. What are its specifications?', 'role': 'user'}
    
    def _create_competitor_prompt(self, url):
        return {
            'content': f'What products on the market are competitive with {url}? Provide a list of potential competitive products.',
            'role': 'user'
        }
    
    def _create_comparison_prompt(self, p1, p2):
        return {
            'content': '''
AI, your job is to closely examine two objects (technologies or machines) and generate two lists: 

1) Generate a list of similarities by recognizing likenesses between the two objects. What do they have in common? How are the items similar?

2) Generate a list of differences by recognizing differences between the two things. How are the object different? Determine which characteristics of each object are different.

Object 1: {0}
Object 2: {1}

AI, generate the list of similarities and the list of differences.
'''.format(p1, p2),
            'role': 'user'
        }
    
    def _parse_competitors(self, ai_list:str):
        lines = ai_list.splitlines()
        prods = []
        for p in lines:
            if len(p) == 0:
                continue
            ind = p.find('-')
            if ind > 0:
                prods.append(p[0:ind])
        
        return prods