
from langchain.chat_models import ChatAnthropic
from langchain.chains import ConversationChain
from langchain.memory import ConversationBufferMemory
from langchain.prompts.chat import (
    ChatPromptTemplate,
    MessagesPlaceholder,
    SystemMessagePromptTemplate,
    AIMessagePromptTemplate,
    HumanMessagePromptTemplate,
)

class Agent:
    _llm = None

    def __init__(self):
        self._llm = ChatAnthropic()
    
    def ask(self, messages):
        input = ""
        message_list = []
        for message in messages:
            if message['role'] == 'user':
                message_list.append(
                    HumanMessagePromptTemplate.from_template(message['content'])
                )
                input = message['content']
            elif message['role'] == 'assistant':
                message_list.append(
                    AIMessagePromptTemplate.from_template(message['content'])
                )

        # Adding SystemMessagePromptTemplate at the beginning of the message_list
        message_list.insert(0, SystemMessagePromptTemplate.from_template(
            "The following is a friendly conversation between a human and an AI. The AI is talkative and "
            "provides lots of specific details from its context. The AI will respond with plain string, replace new lines with \\n which can be easily parsed and stored into JSON, and will try to keep the responses condensed, in as few lines as possible."
        ))

        message_list.insert(1, MessagesPlaceholder(variable_name="history"))

        message_list.insert(-1, HumanMessagePromptTemplate.from_template("{input}"))

        prompt = ChatPromptTemplate.from_messages(message_list)

        memory = ConversationBufferMemory(return_messages=True)
        conversation = ConversationChain(memory=memory, prompt=prompt, llm=self._llm)
        return conversation.predict(input=input)